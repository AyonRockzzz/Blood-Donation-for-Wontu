<?php
include "dbConnection.php";
if (isset($_POST['deleteUser'])) {

   // echo $_POST['deletePhone'];

   $phone = $_POST['deletePhone'];
   $password = md5($_POST['deletePassword']);
   $id = $_GET['id'];


   // echo $phone . '----' . $password . '---------' . $id . '---';


   $sql = "SELECT * FROM  userdata WHERE  password='$password' AND phone ='$phone'";

   $result = mysqli_query($conn, $sql);
   $data = mysqli_fetch_assoc($result);

   if ($result) {

      $rows = mysqli_num_rows($result);
      if ($rows == 1) {

         $sql = "DELETE FROM `userdata` WHERE userdata.id=$id";
         $result = mysqli_query($conn, $sql);

         if ($result) {
            session_start();
            session_destroy();
            echo 'deleted';
            header("Location:../register.php?deleteMessage=You can Register again");
         } else
            echo 'not deleted';
      }else
      header("Location:../user/update.php?deleteMessage=Your password dont match");


   }
} else {
   echo 'alian enter';
   header("Location:../user/update.php?passError=You are an alian");
}
