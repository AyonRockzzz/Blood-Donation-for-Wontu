<?php 
include "dbConnection.php";
if(isset($_GET['search'])){

   function validate($data){ 
     // $data=trim($data);
      $data=stripslashes($data);
      $data=htmlspecialchars($data);
      return $data;
   }

   $bloodGroup=validate($_GET['bloodGroup']);
   $city=validate($_GET['city']);

   $sql="SELECT * FROM userdata WHERE address='$city' OR blood_group='$bloodGroup'";
   $result=mysqli_query($conn,$sql);
  
  

   // if($result){
      
   //    $row=mysqli_num_rows($result);
   //    if($row>0){
   //       echo $row;
   //       // header("Location:../search.php?");
   //    }else{
   //       echo 'no record';
   //       // header("Location:../search.php?");
   //    }

   // }else{

   // }
   // print_r( $result);
 



// $row =mysqli_fetch_assoc($result);
// print_r($row);


echo '<br>';


// while($row=mysqli_fetch_assoc($result)){
  
//    echo $row['fullName'];

// }

}
?>