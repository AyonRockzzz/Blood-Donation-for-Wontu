<?php

   $name="localhost";
   $userName="root";
   $password="";

   $db_name="blood_donate";

   $conn=mysqli_connect($name,$userName,$password,$db_name);

   if(!$conn)
   echo "connection error !";
?>