<?php

include "dbConnection.php";

if (isset($_POST['update_pass'])) {
   // echo $_GET['id'];

   $id = $_GET['id'];
   $oldPassword = md5($_POST['oldPassword']);
   $newPassword = md5($_POST['newPassword']);
   $confirmPassword = md5($_POST['confirmPassword']);

   // echo 'dsfgs ';
   if ($newPassword == $confirmPassword) {

      $sql = "SELECT * FROM  userdata WHERE id ='$id' AND password='$oldPassword'";

      $result = mysqli_query($conn, $sql);




      // print_r(mysqli_fetch_assoc($result));

      if ($result) {
         $rows = mysqli_num_rows($result);
         if ($row = 1) {

            $sql = "UPDATE `userdata` SET `password` = '$newPassword' WHERE `userdata`.`id` = '$id'";

            $result = mysqli_query($conn, $sql);

            if ($result)
               header("Location:../index.php");
            else
               header("Location:../user/update.php?passError=result not match ");
         }
      }
   } else {
      header("Location:../user/update.php?passError=Password not match");
   }
}
