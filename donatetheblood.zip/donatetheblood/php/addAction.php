<?php

if (isset($_POST['create'])) {

   include "dbConnection.php";

   function validate($data)
   {
      // $data=trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
   }

   $name = validate($_POST['name']);
   $number = validate($_POST['number']);
   $email = validate($_POST['email']);
   $address = validate($_POST['address']);
   $bloodGroup = validate($_POST['bloodGroup']);


   $donorData = "name=" . $name . ' &number=' . $number . '&email=' . $email . '&address=' . $address . '&bloodGroup=' . $bloodGroup;

   echo $donorData;

   if (empty($name) || empty($number) || empty($address) || empty($bloodGroup)) {
      header("Location:../donor.php?error=Give your info properly&$donorData");
      // echo $donorData. 'info';
   } else {
      $sql = "INSERT INTO `donor` (`fullName`, `num`, `email`, `addresses`, `blood_group`)
                         VALUES('$name','$number','$email','$address','$bloodGroup')";

      $result = mysqli_query($conn, $sql);

      if ($result) {
         header("Location:../donor.php?message=Successfully added the donor");
      } else {
         header("Location:../donor.php?error=unnown error&$donorData");
         //  echo $donorData .' error';
      }
   }
}
