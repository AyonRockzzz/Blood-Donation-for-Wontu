<?php
session_start();
include "dbConnection.php";




$errors = [];
if (isset($_POST['update'])) {
   function validate($data)
   {
      // $data=trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
   }

   $name = validate($_POST['fullName']);
   $number = validate($_POST['phone']);
   $email = validate($_POST['email']);
   $gender = validate($_POST['gender']);
   $bloodGroup = validate($_POST['bloodGroup']);
   $city = validate($_POST['city']);


   $donateStatus = $_POST['donateStatus'];
   $donateDate = $_POST['donateDate'];

   if ($donateStatus == "yes") {
      $donateDate = $donateDate;
   } else {
      $donateDate = NULL;
   }



   $userData = '  name=' . $name . '&number=' . $number . '&email=' . $email . '&gender=' . $gender . '&bloodGroup=' . $bloodGroup;



   echo $userData;

   if (empty($name)) {
      array_push($errors, "Name is required");
   }
   if (empty($number)) {
      array_push($errors, "phone is required");
   }
   if (empty($gender)) {
      array_push($errors, "Gender is required");
   }
   if (empty($city)) {
      array_push($errors, "City is required");
   }




   $today = date('Y/m/d');
   $diff = date_diff(date_create($donateDate), date_create($today));

   echo '<br>' . $diff->format("%R%a") . '<br>';

   if ($diff->format("%R%a") < 0) {
      array_push($errors, "Date is not valid");
      echo 'invalid';
   }


   $id = $_GET['id'];

   $sql = "SELECT * FROM `userdata` WHERE id='$id'";
   $result = mysqli_query($conn, $sql);
   $rows = mysqli_num_rows($result);


   echo 'row'.$rows.'<br>';

   $userData = mysqli_fetch_assoc($result);

   if (count($errors) == 0 && $rows == 1) {

      echo 'updating...</br>';

      $sql = "UPDATE `userdata` SET `fullName` = '$name', `phone` = '$number', `email` = '$email', `blood_group` = '$bloodGroup',`last_donate_date`='$donateDate', `gender` = '$gender', `address` = '$city' WHERE `userdata`.`id` = $id;";
      $result = mysqli_query($conn, $sql);

      if ($result) {

         $_SESSION['phone'] = $number;
         $_SESSION['userName'] = $name;
         $_SESSION['success'] = 'You are added in our database';
         echo 'updated </br>';
         header("Location:../user/update.php");
         //header("Location:../index.php?message=Successfully updated the user");
      } else {
         //header("Location:register.php?error=unnown error&$userdata");
         echo  'sql  error';
         print_r($userData);
         $_SESSION['updateError']=$errors;
      }
   } else {
      //header("Location:../register.php?error=give your info");
      print_r($errors);
   }
}
