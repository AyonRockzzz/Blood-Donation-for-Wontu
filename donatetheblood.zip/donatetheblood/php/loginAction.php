<?php
include "dbConnection.php";
session_start();
if (isset($_POST['login'])) {


   // echo 'login ';
   // echo $_POST['phone'];
   // echo $_POST['password'] . ' - ';


   function validate($data)
   {
      // $data=trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
   }

   $phone = validate($_POST['phone']);
   $password = validate($_POST['password']);
   $password = md5($_POST['password']);

   //  echo $password .' =  '.$phone;

   $sql = "SELECT * FROM userdata WHERE phone ='$phone' && password ='$password'";
   $result = mysqli_query($conn, $sql);

   if ($result) {
      $row = mysqli_num_rows($result);
      // echo $row;
      // echo' --name--'. mysqli_fetch_assoc($result)['fullName'];

      $userData=mysqli_fetch_assoc($result);
      // print_r($userData);
      if ($row > 0) {

         $_SESSION['phone'] = $phone;
         $_SESSION['userName']=$userData['fullName'];
         $_SESSION['success'] = 'You are added in our database';


         header("Location:../index.php?message=Successfully added the donor");
      }else{
         header("Location:../login.php?error=Username and password combination does not match&phone=$phone");

      }
   } else {
      echo ' error';
   }
}
