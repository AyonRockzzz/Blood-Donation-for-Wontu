<?php 
   include "dbConnection.php";

   $sql="SELECT * FROM userdata ORDER BY fullName ";
   $result =mysqli_query($conn,$sql);

?>