<?php
session_start();
include "dbConnection.php";




$errors = [];
if (isset($_POST['register'])) {
   function validate($data)
   {
      // $data=trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
   }

   $name = validate($_POST['fullName']);
   $number = validate($_POST['phone']);
   $email = validate($_POST['email']);
   $gender = validate($_POST['gender']);
   $bloodGroup = validate($_POST['bloodGroup']);
   $city = validate($_POST['city']);

   $donateStatus = $_POST['donateStatus'];
   $donateDate = $_POST['donateDate'];

   if ($donateStatus == "yes") {
      $donateDate = $donateDate;
   } else {
      $donateDate = NULL;
   }
 

   $password_1 = validate($_POST['password']);
   $password_2 = validate($_POST['confirmPassword']);
   $userData = 'name=' .$name . '&number=' . $number . '&email=' . $email . '&gender=' . $gender . '&bloodGroup=' . $bloodGroup . '&donateStatus=' . $donateStatus . '&donateDate=' . $donateDate ;

 

   if (empty($name)) {
      array_push($errors, "Name is required");
   }
   if (empty($number)) {
      array_push($errors, "phone is required");
   }
   if (empty($gender)) {
      array_push($errors, "Gender is required");
   }
   if (empty($city)) {
      array_push($errors, "City is required");
   }
   if (empty($password_1)) {
      array_push($errors, "Password is required");
   }
   if ($password_1 != $password_2) {
      array_push($errors, "Password does not match");
   }


 
   $today = date('Y/m/d');
   $diff = date_diff(date_create($donateDate),date_create($today));

   echo '<br>' .$diff->format("%R%a"). '<br>';

   if ($diff->format("%R%a") < 0) {
      array_push($errors, "Date is not valid");
      echo 'invalid';
   }

   $sql = "SELECT fullName FROM `userdata` WHERE phone='$number'";
   $result = mysqli_query($conn, $sql);
   $rows = mysqli_num_rows($result);
   if ($rows != 0) {
      array_push($errors, "Number is alradey entered");
   }

   // print_r($errors);


   if (count($errors) == 0) {

      $password = md5($password_1);
      $sql = "INSERT INTO userdata (fullName,phone,email,blood_group,last_donate_date,gender,address,password) 
                  VALUES('$name','$number','$email','$bloodGroup','$donateDate','$gender','$city','$password')";
      mysqli_query($conn, $sql);

      if ($result) {
         // echo ' ---success';
         $_SESSION['phone'] = $number;
         $_SESSION['userName'] = $name;
         $_SESSION['success'] = 'You are added in our database';

         header("Location:../index.php?message=Successfully added the user");
      } else {
         //   header("Location:register.php?error=unnown error&$userdata");
         echo $userData . ' error<br>';
      }
         echo $userData . ' error<br>';
   } else {
      echo $userData . ' <br>';
      print_r($errors);
       header("Location:../register.php?".$userData);
       $_SESSION['regError']=$errors;
   }
}
