-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2021 at 07:46 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_donate`
--

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE `userdata` (
  `id` int(11) NOT NULL,
  `fullName` text NOT NULL,
  `phone` text NOT NULL,
  `email` text DEFAULT NULL,
  `blood_group` text NOT NULL,
  `gender` text NOT NULL,
  `last_donate_date` date DEFAULT NULL,
  `address` text NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`id`, `fullName`, `phone`, `email`, `blood_group`, `gender`, `last_donate_date`, `address`, `password`) VALUES
(49, 's', '01635069081', 'a@a.a', 'O+', 'Male', '2021-05-05', 'Dhaka', '0cc175b9c0f1b6a831c399e269772661'),
(50, 'w', '01414775', 'w@w.what', 'B-', 'Male', '2021-05-01', 'Rangpur', 'f1290186a5d0b1ceab27f4e77c0c5d68'),
(51, 'w', '01719944007', 'w@w.w', 'A+', 'Male', '2021-05-28', 'Dhaka', 'f1290186a5d0b1ceab27f4e77c0c5d68'),
(52, 'e', '0165888588', 'e@e.e', 'A+', 'Male', '2021-05-27', 'Dhaka', 'e1671797c52e15f763380b45e841ec32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userdata`
--
ALTER TABLE `userdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;