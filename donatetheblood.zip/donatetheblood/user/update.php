<?php
session_start();
include 'include/header.php';

if (isset($_SESSION['userName'])) {
	echo 'hello';

	include 'include/sidebar.php';

?>

	<style>
		.form-group {
			text-align: left;
		}

		.form-container {

			padding: 20px 10px 20px 30px;

		}
	</style>


	<?php

	include "../php/dbConnection.php";
	$name = $_SESSION['userName'];
	$sql = "SELECT * FROM userdata WHERE fullName='$name'";
	$result = mysqli_query($conn, $sql);

	if ($result) {


		$data = mysqli_fetch_assoc($result);
	} else {
		echo 'error';
	}



	?>


	<div class="container" style="padding: 60px 0;">
		<div class="row">

			<div class=" card col-md-6 offset-md-3">
				<div class="panel panel-default" style="padding: 20px;">

					<!-- Error Messages -->

					<?php

					if (isset($_SESSION['updateError'])) { ?>
						<div class="alert alert-danger">
							<?php
							if (isset($_SESSION['updateError'])) {
								foreach ($_SESSION['updateError'] as $val) {
									echo $val . '<br>';
								}
							}
							unset($_SESSION['updateError']);
							?>
						</div>
					<?php } ?>



					<form action="../php/userDataUpdateAction.php?id=<?php echo $data['id'] ?>" method="post" class="form-group form-container">
						<div class="form-group">
							<label for="name">Name</label>
							<input type="text" required name="fullName" class="form-control" value="<?php echo $data['fullName']; ?>">
						</div>
						<div class="form-group">
							<label for="name">Blood Group</label><br>
							<select class="form-control demo-default" required id="blood_group" name="bloodGroup" required>
								<option value=""> </option>
								<option value="A+" <?php if ($data['blood_group'] == 'A+') {
																echo 'selected';
															} ?>>A+</option>
								<option value="A-" <?php if ($data['blood_group'] == 'A-') {
																echo 'selected';
															} ?>>A-</option>
								<option value="B+" <?php if ($data['blood_group'] == 'B+') {
																echo 'selected';
															} ?>>B+</option>
								<option value="B-" <?php if ($data['blood_group'] == 'B-') {
																echo 'selected';
															} ?>>B-</option>
								<option value="O+" <?php if ($data['blood_group'] == 'O+') {
																echo 'selected';
															} ?>>O+</option>
								<option value="O-" <?php if ($data['blood_group'] == 'O-') {
																echo 'selected';
															} ?>>O-</option>
								<option value="AB+" <?php if ($data['blood_group'] == 'AB+') {
																echo 'selected';
															} ?>>AB+</option>
								<option value="AB-" <?php if ($data['blood_group'] == 'AB-') {
																echo 'selected';
															} ?>>AB-</option>
							</select>
						</div>


						<script>
							function calander(x) {
								if (x == 1) {
									document.getElementById('calander').style.display = "block";
									console.log("1 is pass");
								} else {
									document.getElementById('calander').style.display = "none";
									console.log("0 is pass");

								}
								return;


							}
						</script>

						<div class="form-group">
							<label for="donateStatus">Do you donate blood before ? </label>

							<input type="radio" name="donateStatus" value="yes" onclick="calander(1)" checked>
							<label for="donateStatus" class="mr-4">Yes</label>
							<input type="radio" name="donateStatus" value="no" onclick="calander(0)">
							<label for="donateStatus">NO</label>

						</div>
						<div class="form-group" id="calander">
							When you donate blood :
							<input type="date" name="donateDate" value="<?php echo $data['last_donate_date']; ?>">
						</div>
						<!--End form-group-->
						<div class="form-group">
							<label for="gender">Gender</label><br>
							<select name="gender" id="gender" class="form-control" required>
								<!-- <option value=""></option> -->
								<option value="Male" <?php if ($data['gender'] == 'Male') {
																echo 'selected';
															} ?>>Male</option>
								<option value="Female <?php if ($data['gender'] == 'Female') {
																	echo 'selected';
																} ?>">Female</option>
							</select>
						</div>
						<!--gender-->
						<div class="form-group">
							<label for="email">Email</label>
							<input type="email" name="email" class="form-control" value="<?php echo $data['email'] ?>">
						</div>
						<div class="form-group">
							<label for="contact_no">Contact No</label>
							<input type="text" name="phone" value="<?php echo $data['phone'] ?>" class="form-control" required title="11 numeric characters only" maxlength="11">
						</div>
						<!--End form-group-->
						<div class="form-group">
							<label for="city">City</label>
							<select name="city" class="custom-select">
								<!-- <option disabled selected value> select your blood group</option> -->
								<option value="Dhaka" <?php if ($data['address'] == 'Dhaka') {
																	echo 'selected';
																} ?>>Dhaka</option>
								<option value="Chottogram" <?php if ($data['address'] == 'Chottogram') {
																		echo 'selected';
																	} ?>>Chottogram</option>
								<option value="Rangpur" <?php if ($data['address'] == 'Rangpur') {
																	echo 'selected';
																} ?>>Rangpur</option>
								<option value="Sylhet" <?php if ($data['address'] == 'Sylhet') {
																	echo 'selected';
																} ?>>Sylhet</option>
								<option value="Barishal" <?php if ($data['address'] == 'Barishal') {
																		echo 'selected';
																	} ?>>Barishal</option>
								<option value="Khulna" <?php if ($data['address'] == 'Khulna') {
																	echo 'selected';
																} ?>>Khulna</option>

							</select>


						</div>
						<!--city end-->

						<div class="form-group">
							<button class="btn btn-lg btn-danger center-aligned" type="submit" name="update">Update</button>
						</div>
					</form>
				</div>
			</div>
			<div class="card col-md-6 offset-md-3">
				<div class="panel panel-default" style="padding: 20px;">


					<!-- Messages -->

					<?php
					if (isset($_GET['passError'])) {
					?>

						<div class="alert alert-danger">
							<?php echo $_GET['passError']; ?>
						</div>
					<?php	} ?>

					<form action="../php/updatePasswordAction.php?id=<?php echo $data['id'] ?>" method="post" class="form-group form-container">

						<div class="form-group">
							<label for="oldpassword">Current Password</label>
							<input type="password" required name="oldPassword" placeholder="Current Password" class="form-control">
						</div>
						<div class="form-group">
							<label for="newPassword">New Password</label>
							<input type="password" required name="newPassword" placeholder="New Password" class="form-control">
						</div>

						<div class="form-group">
							<label for="confirmPassword">Confirm Password</label>
							<input type="password" required name="confirmPassword" placeholder="Confirm Password" class="form-control">
						</div>
						<div class="form-group">
							<button class="btn btn-lg btn-danger center-aligned" type="submit" name="update_pass">Update Password</button>
						</div>
					</form>
				</div>
			</div>


			<div class="card col-md-6 offset-md-3">

				<!-- Display Message -->
				<?php
				if (isset($_GET['deleteMessage'])) {
				?>
					<div class="alert alert-danger">
						<?php echo $_GET['deleteMessage']; ?>
					</div>
				<?php } ?>


				<div class="panel panel-default" style="padding: 20px;">
					<form action="../php/deleteUserAction.php?id=<?php echo $data['id'] ?>" method="post" class="form-group form-container">

						<div class="form-group">
							<label for="deletePhone">Phone</label>
							<input type="text" required name="deletePhone" placeholder="enter your phone" class="form-control">
						</div>
						<div class="form-group">
							<label for="deletePassword">Password</label>
							<input type="password" required name="deletePassword" placeholder="Current Password" class="form-control">
						</div>

						<div class="form-group">
							<button class="btn btn-lg btn-danger center-aligned" type="submit" name="deleteUser">Delete Account</button>
						</div>

					</form>
				</div>
			</div>

		</div>
	</div>

<?php

} else {
	header("Location:../login.php");
}

?>


<?php
include 'include/footer.php';
?>