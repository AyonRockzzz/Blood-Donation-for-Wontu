<?php
session_start();
include('include/header.php');

?>

<style>
	.size {
		min-height: 0px;
		padding: 60px 0 40px 0;

		padding: 2px;
		z-index: 1;
	}

	/* .loader .fa {} */

	.loader {
		display: none;
		width: 69px;
		height: 89px;
		position: absolute;
		top: 25%;
		left: 50%;
		color: #e74c3c;
		font-size: 52px !important;
	}

	.form-group {
		text-align: left;
	}

	h1 {
		color: white;
	}

	h3 {
		color: #e74c3c;
		text-align: center;
	}

	.red-bar {
		width: 25%;
	}

	span {
		display: block;
	}

	.name {
		color: #e74c3c;
		font-size: 22px;
		font-weight: 700;
	}

	.donors_data {
		background-color: white;
		border-radius: 5px;
		margin: 20px 5px 0px 5px;
		-webkit-box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
		-moz-box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
		box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
		padding: 20px;
	}
</style>
<div class="container-fluid red-background size">

	<div class="row">
		<div class="col-md-6 offset-md-3 pt-5 pb-5">
			<h1 class="text-center">Donors</h1>
			<hr class="white-bar">
			<h3 class="text-white">
				<?php

				include "php/readAction.php";
				echo 'Total donor :  ';
				print_r(mysqli_num_rows($result));

				if (mysqli_num_rows($result)) {

				?>



			</h3>
		</div>
	</div>
</div>


<div class="container-fluid">
	<div calss="row data">

		<?php
					if (isset($_SESSION['success'])) {
		?>
			<h2 class="alert alert-success">
			<?php
						echo 'Your data :' . $_SESSION['success'];
					}

			?>
			</h2>
	</div>


	<div class="row data">



		<!-- Button trigger modal -->


		<?php
					if (isset($_GET['error'])) {
		?>
			<div class="w-100  alert alert-danger" role="alert">
				<?php echo $_GET['error']; ?>
			</div>
		<?php } ?>
		<?php
					if (isset($_GET['message'])) {
		?>
			<div class="w-100  alert alert-success" role="alert">
				<?php echo $_GET['message'] ?>
			</div>
		<?php } ?>

	</div>
</div>




<table class="table table-hover text-center">

	<thead>
		<tr>
			<th scope="col">Id</th>
			<th scope="col">Name</th>
			<th scope="col">Number</th>
			<th scope="col">Blood group</th>
			<th scope="col">Last donate date<br> (yyyy-mm-dd)</th>
			<th scope="col">Is available</th>
			<th scope="col">Address</th>
			<th scope="col">Email</th>
			<th scope="col">Gender</th>

		</tr>
	</thead>
	<tbody>
		<?php
					while ($rows = mysqli_fetch_assoc($result)) {
						if ($rows['last_donate_date'] != '0000-00-00') {
							$today = date('Y/m/d');
							$diff = date_diff(date_create($rows['last_donate_date']), date_create($today));
							if ($diff->days >= 120) {
								$is_available = 'Yes';
							} else $is_available = 'No';
						} else $is_available = 'yes';
		?>
			<tr>
				<td><?php echo $rows['id']; ?></td>
				<td><?php echo $rows['fullName']; ?></td>
				<td><?php echo $rows['phone']; ?></td>
				<td><?php echo $rows['blood_group']; ?></td>
				<td><?php echo $rows['last_donate_date'] ?> </td>
				<td><?php echo $is_available ?> </td>
				<td><?php echo $rows['address']; ?></td>
				<td><?php echo $rows['email']; ?></td>
				<td><?php echo $rows['gender']; ?></td>

			<?php } ?>
			</tr>
		<?php } ?>

	</tbody>
</table>

<div class="loader" id="wait">
	<i class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></i>
</div>

<?php

include('include/footer.php');

?>