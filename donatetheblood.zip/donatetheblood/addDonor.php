<!-- Button trigger modal -->
<?php
if (isset($_GET['error'])) {
?>
	<div class="w-100  alert alert-danger" role="alert">
		<?php echo $_GET['error']; ?>
	</div>
<?php } ?>
<?php
if (isset($_GET['message'])) {
?>
	<div class="w-100  alert alert-success" role="alert">
		<?php echo $_GET['message'] ?>
	</div>
<?php } ?>

<button type="button " class="btn btn-danger mb-3" data-toggle="modal" data-target="#addDonor">Add Donors</button>

<!-- Modal -->
<div class="modal fade " id="addDonor" tabindex="-1" role="dialog" aria-labelledby="addTitle" aria-hidden="true" data-backdrop="static">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">


			<div class="modal-header">
				<h5 class="modal-title" id="addTitle">Add Donor</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form method="post" action="php/addAction.php">
				<div class="modal-body">



					<div class="form-group row">
						<label for="name" class="col-sm-2 col-form-label">Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control-plaintext" id="name" name="name" value="<?php if (isset($_GET['name'])) echo ($_GET['name']); ?>" placeholder="Enter your name ">
						</div>
					</div>
					<div class="form-group row">
						<label for="mobile" class="col-sm-2 col-form-label">Number</label>
						<div class="col-sm-10">
							<input type="number" class="form-control-plaintext" id="mobile" name="number" value="<?php if (isset($_GET['number'])) echo ($_GET['number']); ?>" placeholder="Enter your number ">
						</div>
					</div>
					<div class="form-group row">
						<label for="email" class="col-sm-2 col-form-label">Email</label>
						<div class="col-sm-10">
							<input type="email" class="form-control-plaintext" id="email" name="email" value="<?php if (isset($_GET['email'])) echo ($_GET['email']); ?>" placeholder="Enter your email ">
						</div>
					</div>
					<div class="form-group row">
						<label for="address" class="col-sm-2 col-form-label">Address</label>
						<div class="col-sm-10">
							<input type="text" class="form-control-plaintext" id="address" name="address" value="<?php if (isset($_GET['address'])) echo ($_GET['address']); ?>" placeholder="Enter your address ">
						</div>
					</div>

					<select name="bloodGroup" class="custom-select">
						<!-- <option disabled selected value> select your blood group</option> -->
						<option value="A+">A+</option>
						<option value="A-">A-</option>
						<option value="B+">B+</option>
						<option value="B-">B-</option>
						<option value="AB+">AB+</option>
						<option value="AB-">AB-</option>
						<option value="O+">O+</option>
						<option value="O-">O-</option>
					</select>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					<button type="submit" name="create" class="btn btn-primary">Add Donor</button>
				</div>

			</form>

		</div>
	</div>
</div>




</div>
</div>