<?php
session_start();

//include header file
include('include/header.php');

if (isset($_SESSION['success'])) {
	header("Location:donor.php");
}


?>

<style>
	.size {
		min-height: 0px;
		padding: 60px 0 60px 0;

	}

	h1 {
		color: white;
	}

	.form-group {
		text-align: left;
	}

	h3 {
		color: #e74c3c;
		text-align: center;
	}

	.red-bar {
		width: 25%;
	}

	.form-container {
		background-color: white;
		border: .5px solid #eee;
		border-radius: 5px;
		padding: 20px 10px 20px 30px;
		-webkit-box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
		-moz-box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
		box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
	}
</style>

<div class="container-fluid red-background size">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h1 class="text-center">Register Now</h1>
			<hr class="white-bar">
		</div>
	</div>
</div>
<div class="conatiner size ">
	<div class="row">
		<div class="col-md-6 offset-md-3 form-container">
			<h3>Register Now</h3>
			<hr class="red-bar">

			<!-- Erorr Messages -->


			<?php

			if (isset($_SESSION['regError'])) { ?>
				<div class="alert alert-danger">
					<?php
					if (isset($_SESSION['regError'])) {
						foreach ($_SESSION['regError'] as $val) {
							echo $val . '<br>';
						}
					} 
				unset($_SESSION['regError']);
					?>
				</div>
			<?php } ?>

			<?php if (isset($_GET['message'])) { ?>
				<div class="alert alert-success">
					<?php echo $_GET['message']; ?>
				</div>
			<?php }


			?>


			<!-- delete account message -->

			<?php
			if (isset($_GET['deleteMessage'])) {
			?>
				<div class="alert alert-warning">
					<?php echo $_GET['deleteMessage']; ?>
				</div>
			<?php } ?>





			<form action="php/registerAction.php" method="post">

				<div class="form-group">
					<label for="fullName">Full Name</label>
					<input type="text" name="fullName" class="form-control" placeholder="Enter your full name" required
					value="<?php if(isset($_GET['name'])) {
						echo$_GET['name'];}?>">
				</div>
				<div class="form-group">
					<label for="phone">Contact No.</label>
					<input type="number" maxlength="11" name="phone" class="form-control" placeholder="Enter your contact No ." required
					value="<?php if(isset($_GET['number'])) {
						echo$_GET['number'];}?>">
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" name="email" class="form-control" placeholder="Enter your email (optional) ."
					value="<?php if(isset($_GET['email'])) {
						echo$_GET['email'];}?>">
				</div>
				<div class="form-group">
					<label for="gender">Gender</label>
					<select name="gender" class="custom-select" >
						<!-- <option disabled selected value> select your blood group</option> -->
						<option value="Male">Male</option>
						<option value="female">female</option>
					</select>

				</div>
				<div class="form-group">
					<label for="bloodGroup">Blood group</label>
					<select name="bloodGroup" class="custom-select">
						<!-- <option disabled selected value> select your blood group</option> -->
						<option value="A+">A+</option>
						<option value="A-">A-</option>
						<option value="B+">B+</option>
						<option value="B-">B-</option>
						<option value="AB+">AB+</option>
						<option value="AB-">AB-</option>
						<option value="O+">O+</option>
						<option value="O-">O-</option>
					</select>

				</div>
				<div class="form-group">
					<label for="city">City</label>
					<select name="city" class="custom-select">
						<!-- <option disabled selected value> select your blood group</option> -->
						<option value="Dhaka">Dhaka</option>
						<option value="Chottogram">Chottogram</option>
						<option value="Rangpur">Rangpur</option>
						<option value="Sylhet">Sylhet</option>
						<option value="Barishal">Barishal</option>
						<option value="Khulna">Khulna</option>

					</select>

				</div>
				<script>
					function calander(x) {
						if (x == 1) {
							document.getElementById('calander').style.display = "block";
							console.log("1 is pass");
						} else {
							document.getElementById('calander').style.display = "none";
							console.log("0 is pass");

						}
						return;


					}
				</script>

				<div class="form-group">
					<label for="donateStatus">Do you donate blood ? </label>

					<input type="radio" name="donateStatus" value="yes" onclick="calander(1)" checked>
					<label for="donateStatus" class="mr-4">Yes</label>
					<input type="radio" name="donateStatus" value="no" onclick="calander(0)">
					<label for="donateStatus">NO</label>

				</div>
				<div class="form-group" id="calander">
					When you donate blood :
					<input type="date" name="donateDate" value="">
				</div>



				<div class="form-group">
					<label for="password">Password</label>
					<input type="password" name="password" placeholder="Password" required class="form-control">
				</div>
				<div class="form-group">
					<label for="password">Confirm Password</label>
					<input type="password" name="confirmPassword" placeholder="Confirm Password" required class="form-control">
				</div>
				<div class="form-group">
					<button class="btn btn-danger btn-lg center-aligned" type="submit" name="register">Register</button>
				</div>
				Alradey have an account ? <a href="login.php"> Log in now</a>

			</form>
		</div>
	</div>
</div>
<?php include 'include/footer.php' ?>